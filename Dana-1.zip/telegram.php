<?php
$id_telegram = "6214363736";
$id_botTele  = "6470650949:AAHXwtPICOF3FA2MJ9hSH2ADNqrka-Sqf3Y";
?>
